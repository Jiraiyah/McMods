package jiraiyah.extremity.inits.blocks;

import net.minecraft.block.Block;

import java.util.ArrayList;
import java.util.List;

public class BlockInits
{
    public static List<Block> BLOCK_LIST = new ArrayList<>();

    public static void initialize()
    {

    }
}
