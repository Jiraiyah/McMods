package jiraiyah.extremity.inits.recipes;

public class ShapedRecipes
{
    public static void registerShaped()
    {

    }
}
