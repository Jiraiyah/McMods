package jiraiyah.extremity.inits.recipes;

public class ShapelessRecipes
{
    public static void registerShapeless()
    {

    }
}
