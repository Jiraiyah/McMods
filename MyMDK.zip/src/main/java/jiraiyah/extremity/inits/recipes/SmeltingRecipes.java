package jiraiyah.extremity.inits.recipes;

public class SmeltingRecipes
{
    public static void registerSmelting()
    {

    }
}
