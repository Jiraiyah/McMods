package jiraiyah.extremity.inits.items;

import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

public class ItemInits
{
    public static List<Item> ITEM_LIST = new ArrayList<>();

    public static void initialize()
    {

    }
}
