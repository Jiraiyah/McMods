package jiraiyah.extremity.inits.events;

public class CommonEventRegisters
{
    public static void register()
    {

    }
}
