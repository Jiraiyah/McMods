package jiraiyah.extremity.inits.events;

public class ClientEventRegisters
{
    public static void register()
    {

    }
}
