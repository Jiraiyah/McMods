package jiraiyah.extremity.inits;

public class KeyBindings
{
    public static void register()
    {

    }
}
