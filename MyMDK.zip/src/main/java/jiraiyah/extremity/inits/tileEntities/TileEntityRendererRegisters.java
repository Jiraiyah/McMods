package jiraiyah.extremity.inits.tileEntities;

public class TileEntityRendererRegisters
{
    public static void register()
    {

    }
}
