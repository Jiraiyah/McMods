package jiraiyah.extremity.inits.tileEntities;

public class TileEntityRegisters
{
    public static void register()
    {

    }
}
